#include "Game.h"
#include "Globals.h"
#include "ResourceManager.h"
#include <stdio.h>

Music soundMusic[10];

Game::Game()
{
    scene = nullptr;
    state = GameState::START;
    img_menu = nullptr;
    img_copy = nullptr;
    img_opening = nullptr;
    img_game_over = nullptr;
    img_upc = nullptr;
    img_creators = nullptr;
    img_win = nullptr;

    a = 1;
    TransCondition = true;
    TransCounter = 0;

    GettingTime = true;
    Time = 0;

    target = {};
    src = {};
    dst = {};
}
Game::~Game()
{
    if (scene != nullptr)
    {
        scene->Release();
        delete scene;
        scene = nullptr;
    }
}
AppStatus Game::Initialise(float scale)
{
    
    float w, h;
    w = WINDOW_WIDTH * scale;
    h = WINDOW_HEIGHT * scale;

    //Initialise window
    InitWindow((int)w, (int)h, "Bubble bobble");

    //Render texture initialisation, used to hold the rendering result so we can easily resize it
    target = LoadRenderTexture(WINDOW_WIDTH, WINDOW_HEIGHT);
    if (target.id == 0)
    {
        LOG("Failed to create render texture");
        return AppStatus::ERROR;
    }
    SetTextureFilter(target.texture, TEXTURE_FILTER_POINT);
    src = { 0, 0, WINDOW_WIDTH, -WINDOW_HEIGHT };
    dst = { 0, 0, w, h };

    //Load resources
    if (LoadResources() != AppStatus::OK)
    {
        LOG("Failed to load resources");
        return AppStatus::ERROR;
    }

    //Set the target frame rate for the application
    SetTargetFPS(60);
    //Disable the escape key to quit functionality
    SetExitKey(0);

    

    return AppStatus::OK;
}
AppStatus Game::LoadResources()
{
    ResourceManager& data = ResourceManager::Instance();
    
    if (data.LoadTexture(Resource::IMG_MENU, "images/title-export.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_menu = data.GetTexture(Resource::IMG_MENU);

    if (data.LoadTexture(Resource::IMG_UPC, "images/UPC.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_upc = data.GetTexture(Resource::IMG_UPC);

    if (data.LoadTexture(Resource::IMG_CREATORS, "images/Calidum Bullae.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_creators = data.GetTexture(Resource::IMG_CREATORS);

    if (data.LoadTexture(Resource::IMG_GAME_OVER, "images/Game over.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_game_over = data.GetTexture(Resource::IMG_GAME_OVER);

    if (data.LoadTexture(Resource::IMG_COPY, "images/copy.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_copy = data.GetTexture(Resource::IMG_COPY);

    if (data.LoadTexture(Resource::IMG_OPENING, "images/Cinematic.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_opening = data.GetTexture(Resource::IMG_OPENING);

    return AppStatus::OK;
    if (data.LoadTexture(Resource::IMG_WIN, "images/superdrunk.png") != AppStatus::OK)
    {
        return AppStatus::ERROR;
    }
    img_win = data.GetTexture(Resource::IMG_WIN);

    return AppStatus::OK;
}
int Game::CheckTime()
{
    if (GettingTime == true)
    {
        Time = GetTime();
        GettingTime = false;
    }

    return GetTime() - Time;
}

AppStatus Game::BeginPlay()
{
    scene = new Scene();

    if (scene == nullptr)
    {
        LOG("Failed to allocate memory for Scene");
        return AppStatus::ERROR;
    }
    if (scene->Init() != AppStatus::OK)
    {
        LOG("Failed to initialise Scene");
        return AppStatus::ERROR;
    }

    return AppStatus::OK;
}
void Game::FinishPlay()
{
    scene->Release();
    delete scene;
    scene = nullptr;
}
AppStatus Game::Update()
{
    //Check if user attempts to close the window, either by clicking the close button or by pressing Alt+F4
    if(WindowShouldClose()) return AppStatus::QUIT;
    MusicPlayer();
    UpdateMusicStream(soundMusic[0]);
    switch (state)
    {
        case GameState::START:
            if (TransCounter == 6)
            {
                GettingTime = true;
                state = GameState::MAIN_MENU;
                
            }
            if (IsKeyPressed(KEY_ONE))
            {
                state = GameState::OPENING;
            }
        break;

        case GameState::MAIN_MENU:
            if (IsKeyPressed(KEY_ESCAPE)) return AppStatus::QUIT;
            if (IsKeyPressed(KEY_SPACE))
            {
                state = GameState::OPENING;

            }
            if (IsKeyPressed(KEY_ONE))
            {
                state = GameState::PLAYING;
            }
        break;


   

        case GameState::OPENING:
            
            
            if (IsKeyPressed(KEY_ESCAPE)) return AppStatus::QUIT;
            
            if (CheckTime() > 2)
            {
                if (BeginPlay() != AppStatus::OK) return AppStatus::ERROR;
                
                
                state = GameState::PLAYING;
                i = 0;
                GettingTime = true;
            }
            
        break;
        case GameState::GAME_OVER:
            i = 0;
            PauseMusicStream(soundMusic[0]);
            if (CheckTime() > 3)
            {
                
                state = GameState::MAIN_MENU;
                GettingTime = true;
            }
        break;

        case GameState::WIN:
            i = 0;
            PauseMusicStream(soundMusic[0]);
            if (CheckTime() > 3)
            {

                state = GameState::MAIN_MENU;
                GettingTime = true;
            }
            break;

        case GameState::PLAYING:
        {
            Player* player = scene->GetPlayer();
            if (IsKeyPressed(KEY_ESCAPE))
            {
                //FinishPlay();
                state = GameState::GAME_OVER;

            }
            else if (player->LooseCondition())
            {
                state = GameState::GAME_OVER;
            }
            else if (scene->WinCondition())
            {
                state = GameState::WIN;
            }
            else
            {
                //Game logic
                scene->Update();
            }
        }
        break;
        case GameState::TRANSITION:

            break;
        //case GameState::MAIN_MENU:;
        //    if (IsKeyPressed(KEY_ESCAPE)) return AppStatus::QUIT;
        //    if (IsKeyPressed(KEY_SPACE))
        //    {
        //        if(BeginPlay() != AppStatus::OK) return AppStatus::ERROR;
        //        state = GameState::PLAYING;
        //    }
        //    break;

        //case GameState::PLAYING:  
        //    Player *player = scene->GetPlayer();
        //    if (IsKeyPressed(KEY_ESCAPE))
        //    {
        //        FinishPlay();
        //        StopMusicStream(soundMusic[0]);
        //        state = GameState::MAIN_MENU;
        //    }
        //    else if(player->LooseCondition())
        //    { 
        //        state = GameState::MAIN_MENU;
        //    }
        //    else
        //    {
        //        //Game logic
        //        scene->Update();
        //    }
        //    break;
    }
    return AppStatus::OK;
}
void Game::MusicPlayer()
{
    if (state == GameState::OPENING)
    {
        if (i == 0)
        {
            i++;
            soundMusic[0] = LoadMusicStream("sound/Music/Main-Theme.ogg");
            PlayMusicStream(soundMusic[0]);
        }
    }
    else if (state == GameState::GAME_OVER)
    {
        if (j == 0)
        {
            j++;
            soundMusic[1] = LoadMusicStream("sound/Music/9-Game-Over.ogg");
            PlayMusicStream(soundMusic[1]);
        }
    }
    else if (state == GameState::MAIN_MENU)
    {
        if (k == 0)
        {
            k++;
            soundMusic[2] = LoadMusicStream("sound/Music/TitleFX.wav");
            PlayMusicStream(soundMusic[2]);
        }
    }

}
void Game::Render()
{
    //Draw everything in the render texture, note this will not be rendered on screen, yet
    BeginTextureMode(target);
    ClearBackground(BLACK);
    int i = 0;
    switch (state)
    {
        case GameState::START:
            if ((TransCounter == 0) || (TransCounter == 1))
            {
                DrawTexture(*img_copy, 0, 0, WHITE);
                Transition();

            }
            else if ((TransCounter == 2) || (TransCounter == 3))
            {
                DrawTexture(*img_upc, 0, 0, WHITE);
                Transition();

            }
            else if ((TransCounter == 4) || (TransCounter == 5))
            {
                DrawTexture(*img_creators, 0, 0, WHITE);
                Transition();

            }

            break;

        case GameState::MAIN_MENU:
            
            DrawTexture(*img_menu, 0, 0, WHITE);
            
            break;
    
        case GameState::OPENING:
            DrawTexture(*img_opening, 0, 0, WHITE);
            break;

        case GameState::GAME_OVER:
            DrawTexture(*img_game_over, 0, 0, WHITE);
            break;

        case GameState::PLAYING:
            scene->Render();
            break;


    /*    case GameState::TRANSITIONING:
            float progress = timeElapsed / totalTime;
            float yPos_stage2 = 224.0f * -progress;
            if (timeElapsed < totalTime) {
                DrawTexture(*img_stage1, 0, yPos_stage2, WHITE);
                DrawTexture(*img_stage2, 0, yPos_stage2 + 224, WHITE);
                
                timeElapsed += GetFrameTime();

            }
            else {
                
                timeElapsed = 0;
                state = GameState::PLAYING;
                scene->LoadLevel(2);

            }*/

            break;

    }
    
    EndTextureMode();

    //Draw render texture to screen, properly scaled
    BeginDrawing();
    DrawTexturePro(target.texture, src, dst, { 0, 0 }, 0.0f, WHITE);
    EndDrawing();
}
void Game::Cleanup()
{
    UnloadResources();
    CloseWindow();
}
void Game::Transition()
{
    if (TransCondition == true)
    {
        DrawRectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, Fade(BLACK, a));
        a -= 0.02;
    }
    else if (TransCondition == false)
    {
        DrawRectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, Fade(BLACK, a));
        a += 0.02;
    }

    if (a > 1)
    {
        a = 1;
        TransCondition = 1;
        TransCounter++;
    }
    if (a < 0)
    {
        a = 0.0;
        WaitTime(2);
        TransCondition = false;
        TransCounter++;
    }
}
void Game::UnloadResources()
{
    ResourceManager& data = ResourceManager::Instance();
    data.ReleaseTexture(Resource::IMG_CREATORS);
    data.ReleaseTexture(Resource::IMG_OPENING);
    data.ReleaseTexture(Resource::IMG_GAME_OVER);
    data.ReleaseTexture(Resource::IMG_COPY);
    data.ReleaseTexture(Resource::IMG_MENU);
    data.ReleaseTexture(Resource::IMG_UPC);
    data.ReleaseTexture(Resource::IMG_WIN);

    UnloadRenderTexture(target);
}